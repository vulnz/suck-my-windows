# Arguments #
Note: Case sensitive.  

### App arguments ###
-nosplash  
Hide Splashscreen.  
-nowarnOS  
Hide OS compatibility warning. DO IT AT YOUR OWN RISK!  
-proxy  
Get rule updates via proxy. Example: -proxy "127.0.0.1:8080", -proxy "" - go offline.  
-locale  
Force localization culture. Localization.ini required. Example: -locale "en-US"  
-restorePoint  
Create a Restore Point.  
-dumpRules  
Copy firewall rules to "rules.txt". App's folder by default.  
-dumpRules "Path"  
Custom path. No backslash at the end required. Example: -dumpRules "C:\folder"  
-close  
Quit program after arguments execution.  

### Tab arguments ###
-reg4gp  
Use registry for Group Policy instead of group policy objects.  
-nofw  
Bypass Firewall tab loading.  
-noappx  
Bypass Appx tab loading.

### Button arguments ###
Note: Can't be used together. Priority order.  

-default  
Switch everything to default, except Appx.  
-privacyAll  
Switch everything to full privacy, except Appx.  
-privacy ""  
Switch list of buttons to privacy. Example: -privacy "GP1 GP2 Service2 Scheduler3 Rule2 Misc1"  
Full list of buttons below.  
-revert ""  
Revert list of buttons to default state. Example: -revert "GP1 GP2 Service2 Scheduler3 Rule2 Misc1"  
Full list of buttons below.  

### Additional Button arguments ###
-security  
Check "Set Telemetry to Security level". (Windows 10 Enterprise and LTSB/LTSC)  
-includeAdd  
Check "Include All Additional settings". (Windows 10)  
-defender ""  
Enable/disable Windows Defender Firewall. Example: -defender "on", -defender "off"  
-wfp ""  
Enable/disable Windows Filtering Platform. Example: -wfp "on", -wfp "off"  

### List of buttons ###
* GP1 - Internet Explorer Customer Experience Improvement Program
* GP2 - *Empty*
* GP3 - Allow Cortana
* GP4 - Allow search and Cortana to use location
* GP5 - Throttle additional data
* GP6 - Windows Error Reporting
* GP7 - Steps Recorder
* GP8 - Inventory Collector
* GP9 - Telemetry
* GP10 - Input personalization
* GP11 - Handwriting automatic learning / Allow users to enable online speech recognition services
* GP12 - PerfTrack
* GP13 - Microsoft Support Diagnostic Tool
* GP14 - Advertising ID
* GP15 - Windows Customer Experience Improvement Program
* GP16 - Windows Messenger Customer Experience Improvement Program
* GP17 - Search Companion
* GP18 - Microsoft consumer experiences
* GP19 - Improve inking and typing recognition
* 
* Service1 - Diagnostics Tracking Service / Connected User Experiences and Telemetry
* Service2 - Microsoft (R) Diagnostics Hub Standard Collector Service
* Service3 - Device Management Wireless Application Protocol (WAP) Push message Routing Service
* Service4 - DataCollectionPublishingService (DcpSvc)
* Service5 - Windows Media Player Network Sharing Service
* 
* Scheduler1 - Consolidator
* Scheduler2 - KernelCeipTask
* Scheduler3 - UsbCeip
* Scheduler4 - BthSQM
* Scheduler5 - *Empty*
* Scheduler6 - Sqm-Tasks
* Scheduler7 - Proxy
* Scheduler8 - Compatibility Appraiser
* Scheduler9 - ProgramDataUpdater
* Scheduler10 - AitAgent
* Scheduler11 - DiskDiagnosticDataCollector
* Scheduler12 - GatherNetworkInfo
* 
* GPadd1 - Allow publishing of User Activities
* GPadd2 - Allow upload of User Activities
* GPadd3 - Enables Activity Feed
* GPadd4 - Allow Clipboard synchronization across devices
* GPadd5 - Allow device name to be sent in Windows diagnostic data
* GPadd6 - Sync your settings
* GPadd7 - Use OneDrive for file storage
* 
* GPapp1 - Let Windows apps access account information
* GPapp2 - Let Windows apps access the calendar
* GPapp3 - Let Windows apps access call history
* GPapp4 - Let Windows apps access the camera
* GPapp5 - Let Windows apps access the contacts
* GPapp6 - Let Windows apps access email
* GPapp7 - Let Windows apps access an eye tracker device
* GPapp8 - Let Windows apps access location
* GPapp9 - Let Windows apps access messaging
* GPapp10 - Let Windows apps access the microphone
* GPapp11 - Let Windows apps access motion
* GPapp12 - Let Windows apps access notifications
* GPapp13 - Let Windows apps make phone calls
* GPapp14 - Let Windows apps control radios
* GPapp15 - Let Windows apps access Tasks
* GPapp16 - Let Windows apps access trusted devices
* GPapp17 - Let Windows apps access diagnostic information about other apps
* GPapp18 - Let Windows apps run in the background
* GPapp19 - Let Windows apps communicate with unpaired devices
* 
* ServAdd1 - Connected Devices Platform User Service
* ServAdd2 - Sync Host
* ServAdd3 - Contact Data
* ServAdd4 - User Data Storage
* ServAdd5 - User Data Access
* ServAdd6 - MessagingService
* ServAdd7 - Windows Push Notifications User Service
* 
* Misc1 - Show sync provider notifications
* Misc2 - Tailored experiences
* Misc3 - Let Windows track app launches to improve Start and search results
* 
* Rule1 - Firewall Spy
* Rule2 - Firewall Extra
* Rule3 - Firewall Update